# ----基于CNN实现的AE---- #
# ----在mnist_digits数据集上训练---- #
# 环境
# python 3.9.13
# conda 23.3.1
# tensorflow 2.12.0
# matplotlib 3.3.0
# --------------------- #
import math
import numpy as np
from keras.models import Sequential, Model
from keras.layers import Input, Dense, Conv2D, MaxPooling2D, UpSampling2D
from keras.datasets import mnist
import tensorflow as tf
import matplotlib.pyplot as plt
import os


class CAE_d:
    def __init__(self):
        # 输入shape
        self.img_rows = 28
        self.img_cols = 28
        self.channels = 1
        self.img_shape = (self.img_rows, self.img_cols, self.channels)
        self.encoded = self.build_encoder()
        self.decoded = self.build_decoder()
        input = Input(shape=self.img_shape)
        encoded = self.encoded(input)
        output = self.decoded(encoded)
        self.combined = Model(input, output)
        self.combined.compile(loss='binary_crossentropy', optimizer='adam')
        self.feature = (4, 4, 8)

    # 编码器
    def build_encoder(self):
        model = Sequential()
        input = Input(shape=self.img_shape)
        # 三层卷积
        # conv1
        # 28*28*16
        model.add(Conv2D(filters=16, kernel_size=(3, 3), activation='relu', padding='same'))
        # 14*14*16
        model.add(MaxPooling2D(pool_size=(2, 2), padding='same'))
        # conv2
        # 14*14*16
        model.add(Conv2D(filters=16, kernel_size=(3, 3), activation='relu', padding='same'))
        # conv3
        # 14*14*8
        model.add(Conv2D(filters=8, kernel_size=(3, 3), activation='relu', padding='same'))
        # 7*7*8
        model.add(MaxPooling2D(pool_size=(2, 2), padding='same'))
        # conv4
        # 7*7*8
        model.add(Conv2D(filters=8, kernel_size=(3, 3), activation='relu', padding='same'))
        # 4*4*8
        model.add(MaxPooling2D(pool_size=(2, 2), padding='same'))

        encoded = model(input)
        return Model(input, encoded)

    # 解码器
    def build_decoder(self):
        model = Sequential()
        input = Input(shape=(4, 4, 8))
        # 反卷积和上采样
        # conv1
        # 4*4*8
        model.add(Conv2D(filters=8, kernel_size=(3, 3), activation='relu', padding='same'))
        # conv2
        # 4*4*16
        model.add(Conv2D(filters=16, kernel_size=(3, 3), activation='relu', padding='same'))
        # 8*8*16
        model.add(UpSampling2D((2, 2)))
        # conv3
        # 8*8*16
        model.add(Conv2D(filters=16, kernel_size=(3, 3), activation='relu', padding='same'))
        # conv4
        # 8*8*8
        model.add(Conv2D(filters=8, kernel_size=(3, 3), activation='relu', padding='same'))
        # 16*16*8
        model.add(UpSampling2D((2, 2)))
        # conv5
        # 14*14*8
        model.add(Conv2D(filters=16, kernel_size=(3, 3), activation='relu'))
        # 28*28*8
        model.add(UpSampling2D((2, 2)))
        # conv6
        # 28*28*1
        model.add(Conv2D(filters=1, kernel_size=(3, 3), activation='sigmoid', padding='same'))

        output = model(input)
        return Model(input, output)

    # train
    def train(self, epochs, batch_size=128, sample_interval=50):
        # 载入数据库
        # 数据准备预处理
        # mnist digits数据
        #(x_train, _), (x_test, _) = mnist.load_data()
        # mnist fashion数据
        (x_train, _), (x_test, _) = tf.keras.datasets.fashion_mnist.load_data()
        x_train = tf.expand_dims(x_train.astype('float32'), -1) / 255.0
        x_test = tf.expand_dims(x_test.astype('float32'), -1) / 255.0
        # 加噪声
        noise_factor = 0.4
        x_train_noisy = x_train + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_train.shape)
        x_test_noisy = x_test + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_test.shape)

        x_train_noisy = np.clip(x_train_noisy, 0., 1.)
        x_test_noisy = np.clip(x_test_noisy, 0., 1.)

        self.combined.fit(x_train_noisy, x_train_noisy,
                          epochs=epochs,
                          batch_size=batch_size,
                          shuffle=True,
                          validation_data=(x_test_noisy, x_test_noisy))
        dir1 = 'images/CAE_f_noisy.png'
        self.plot_data(x_test_noisy, dir1)
        dir2 = 'images/CAE_f_result.png'
        decoded_img = self.combined.predict(x_test_noisy)
        self.plot_data(decoded_img, dir2)


    def plot_data(self, data, imgdir, n=30, figsize=15):
        # display an n*n 2D manifold of digits
        digit_size = 28
        scale = 1.0
        figure = np.zeros((digit_size * n, digit_size * n))
        # linearly spaced coordinates corresponding to the 2D plot
        # of digit classes in the latent space
        grid_x = np.linspace(-scale, scale, n)
        grid_y = np.linspace(-scale, scale, n)[::-1]

        for i, yi in enumerate(grid_y):
            for j, xi in enumerate(grid_x):
                k = i * n + j
                digit = data[k].reshape(digit_size, digit_size)
                figure[
                i * digit_size: (i + 1) * digit_size,
                j * digit_size: (j + 1) * digit_size,
                ] = digit
        plt.figure(figsize=(figsize, figsize))
        plt.imshow(figure, cmap="Greys_r")
        plt.savefig(imgdir)
        plt.show()


if __name__ == '__main__':
    if not os.path.exists("./images"):
        os.makedirs("./images")
    gan = CAE_d()
    gan.train(epochs=20, batch_size=256)
