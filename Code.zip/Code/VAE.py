# ------VAE变分自编码器------ #
# ----在mnist数据集上训练---- #
# 环境
# python 3.9.13
# conda 23.3.1
# tensorflow 2.12.0
# matplotlib 3.3.0
# ------------------------- #
import numpy as np
from keras.models import Sequential, Model
from keras.layers import Input, Conv2D, Dense, Flatten, Layer, Reshape, Conv2DTranspose
from keras.datasets import mnist
import tensorflow as tf
import matplotlib.pyplot as plt
from keras.metrics import Mean
from keras.losses import binary_crossentropy
from keras.optimizers import Adam
import os


class VAE(Model):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.latent_dim = 2
        self.img_shape = (28, 28, 1)
        self.img_dim = np.prod(self.img_shape)
        self.encoder = self.build_encoder()
        self.decoder = self.build_decoder()
        self.total_loss_tracker = Mean(name="total_loss")
        self.reconstruction_loss_tracker = Mean(name="reconstruction_loss")
        # KL距离
        self.kl_loss_tracker = Mean(name="kl_loss")

    # 采样 再参数化采样
    def Sampling(self, inputs):
        z_mean, z_log_var = inputs
        batch = tf.shape(z_mean)[0]
        dim = tf.shape(z_mean)[1]
        epsilon = tf.random.normal(shape=(batch, dim))
        return z_mean + tf.exp(0.5 * z_log_var) * epsilon

    # 推断网络
    def build_encoder(self):
        model = Sequential()
        input = Input(shape=self.img_shape)
        model.add(Conv2D(32, 3, activation="relu", strides=2, padding="same"))
        model.add(Conv2D(64, 3, activation="relu", strides=2, padding="same"))
        model.add(Flatten())
        model.add(Dense(16, activation="relu"))

        x = model(input)

        # z|x的分布
        z_mean = Dense(self.latent_dim, name="z_mean")(x)
        z_log_var = Dense(self.latent_dim, name="z_log_var")(x)
        # z的采样
        z = self.Sampling([z_mean, z_log_var])

        return Model(input, [z_mean, z_log_var, z], name='encoder')

    # 生成网络
    def build_decoder(self):
        model = Sequential()
        input = Input(shape=(self.latent_dim,))
        model.add(Dense(7 * 7 * 64, activation="relu"))
        model.add(Reshape((7, 7, 64)))
        # 反卷积 扩大特征图
        model.add(Conv2DTranspose(64, 3, activation="relu", strides=2, padding="same"))
        model.add(Conv2DTranspose(32, 3, activation="relu", strides=2, padding="same"))
        model.add(Conv2DTranspose(1, 3, activation="sigmoid", padding="same"))
        output = model(input)

        return Model(input, output, name='decoder')

    # 限制metrics输出
    @property
    def metrics(self):
        return [
            self.total_loss_tracker,
            self.reconstruction_loss_tracker,
            self.kl_loss_tracker,
        ]

    def train_step(self, data):
        with tf.GradientTape() as tape:
            z_mean, z_log_var, z = self.encoder(data)
            reconstruction = self.decoder(z)
            reconstruction_loss = tf.reduce_mean(
                tf.reduce_sum(
                    binary_crossentropy(data, reconstruction), axis=(1, 2)
                )
            )
            # 负的
            kl_loss = -0.5 * (1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var))
            kl_loss = tf.reduce_mean(tf.reduce_sum(kl_loss, axis=1))
            # ELOB
            total_loss = reconstruction_loss + kl_loss
        grads = tape.gradient(total_loss, self.trainable_weights)
        self.optimizer.apply_gradients(zip(grads, self.trainable_weights))
        self.total_loss_tracker.update_state(total_loss)
        self.reconstruction_loss_tracker.update_state(reconstruction_loss)
        self.kl_loss_tracker.update_state(kl_loss)
        return {
            "loss": self.total_loss_tracker.result(),
            "reconstruction_loss": self.reconstruction_loss_tracker.result(),
            "kl_loss": self.kl_loss_tracker.result(),
        }


class Plot:
    def plot_latent_space(self, vae, imgdir, n=30, figsize=15):
        # display an n*n 2D manifold of digits
        digit_size = 28
        scale = 1.0
        figure = np.zeros((digit_size * n, digit_size * n))
        # linearly spaced coordinates corresponding to the 2D plot
        # of digit classes in the latent space
        grid_x = np.linspace(-scale, scale, n)
        grid_y = np.linspace(-scale, scale, n)[::-1]

        for i, yi in enumerate(grid_y):
            for j, xi in enumerate(grid_x):
                z_sample = np.array([[xi, yi]])
                x_decoded = vae.decoder.predict(z_sample)
                # 改变维度，呈现图片
                digit = x_decoded[0].reshape(digit_size, digit_size)
                figure[
                i * digit_size: (i + 1) * digit_size,
                j * digit_size: (j + 1) * digit_size,
                ] = digit

        plt.figure(figsize=(figsize, figsize))
        start_range = digit_size // 2
        end_range = n * digit_size + start_range
        pixel_range = np.arange(start_range, end_range, digit_size)
        sample_range_x = np.round(grid_x, 1)
        sample_range_y = np.round(grid_y, 1)
        plt.xticks(pixel_range, sample_range_x)
        plt.yticks(pixel_range, sample_range_y)
        plt.xlabel("z[0]")
        plt.ylabel("z[1]")
        plt.imshow(figure, cmap="Greys_r")
        plt.savefig(imgdir)
        plt.show()

    """
    ## Display how the latent space clusters different digit classes
    """

    def plot_label_clusters(self, vae, data, labels, imgdir):
        # display a 2D plot of the digit classes in the latent space
        z_mean, _, _ = vae.encoder.predict(data, verbose=0)
        plt.figure(figsize=(12, 10))
        plt.scatter(z_mean[:, 0], z_mean[:, 1], c=labels)
        plt.colorbar()
        plt.xlabel("z[0]")
        plt.ylabel("z[1]")
        plt.savefig(imgdir)
        plt.show()

    def plot_data(self, data, imgdir, n=30, figsize=15):
        # display an n*n 2D manifold of digits
        digit_size = 28
        scale = 1.0
        figure = np.zeros((digit_size * n, digit_size * n))
        # linearly spaced coordinates corresponding to the 2D plot
        # of digit classes in the latent space
        grid_x = np.linspace(-scale, scale, n)
        grid_y = np.linspace(-scale, scale, n)[::-1]

        for i, yi in enumerate(grid_y):
            for j, xi in enumerate(grid_x):
                k = i * n + j
                digit = data[k].reshape(digit_size, digit_size)
                figure[
                i * digit_size: (i + 1) * digit_size,
                j * digit_size: (j + 1) * digit_size,
                ] = digit
        plt.figure(figsize=(figsize, figsize))
        plt.imshow(figure, cmap="Greys_r")
        plt.savefig(imgdir)
        plt.show()


if __name__ == '__main__':
    if not os.path.exists("./images"):
        os.makedirs("./images")

    # 生成图片
    vae = VAE()
    # 准备数据
    (x_train, _), (x_test, _) = mnist.load_data()
    # 数据可视化
    #x = np.expand_dims(x_train, -1).astype("float32") / 255
    #dir1 = 'images/dclass.png'
    #Plot().plot_label_clusters(vae, x, y_train, dir1)
    # 数据预处理
    data = np.concatenate([x_train, x_test], axis=0)
    data = tf.expand_dims(data.astype('float32'), -1) / 255.0
    # 编译模型
    vae.compile(optimizer=Adam())
    vae.fit(data, epochs=15, batch_size=128)

    dir2 = 'images/gendigits.png'
    Plot().plot_latent_space(vae, imgdir=dir2)

    # ------------------------------------------------ #
    # 降噪测试
    vae_noisy = VAE()
    (x_train, y_train), (x_test, _) = mnist.load_data()
    x_train = tf.expand_dims(x_train.astype('float32'), -1) / 255.0
    x_test = tf.expand_dims(x_test.astype('float32'), -1) / 255.0
    # 加噪声
    noise_factor = 0.4
    x_train_noisy = x_train + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_train.shape)
    x_test_noisy = x_test + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_test.shape)

    x_train_noisy = np.clip(x_train_noisy, 0., 1.)
    x_test_noisy = np.clip(x_test_noisy, 0., 1.)
    data_noisy = np.concatenate([x_train_noisy, x_test_noisy], axis=0)
    # 编译模型
    vae_noisy.compile(optimizer=Adam())
    vae_noisy.fit(data_noisy, epochs=15, batch_size=128)

    # 测试集
    _, _, z_noisy = vae_noisy.encoder.predict(x_test_noisy)
    results = vae_noisy.decoder.predict(z_noisy)

    # 测试集可视化
    dir3 = 'images/test_noisy.png'
    Plot().plot_data(x_test_noisy, dir3)
    # 测试结果可视化
    dir4 = 'images/result_noisy.png'
    Plot().plot_data(results, dir4)
