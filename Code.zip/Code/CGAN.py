# --GAN条件生成对抗模型-- #
# --------------------- #
# 环境
# python 3.9.13
# conda 23.3.1
# tensorflow 2.12.0
# matplotlib 3.3.0
# --------------------- #
from __future__ import print_function, division

from keras.datasets import mnist
from keras.layers import Input, Dense, Reshape, Flatten, Dropout, multiply
from keras.layers import BatchNormalization, Activation, Embedding, ZeroPadding2D
from keras.layers import UpSampling2D, Conv2D, LeakyReLU
from keras.models import Sequential, Model
from keras.optimizers.legacy import Adam

import matplotlib.pyplot as plt
import os
import numpy as np


class CGAN():
    def __init__(self):
        # 输入shape
        self.img_rows = 28
        self.img_cols = 28
        self.channels = 1
        self.img_shape = (self.img_rows, self.img_cols, self.channels)
        # 十类
        self.num_classes = 10
        self.latent_dim = 100  # n维随机数
        # adam优化器
        optimizer = Adam(0.0002, 0.5)

        # 判别网络
        # binary_crossentropy针对真伪进行交叉熵计算；sparse_categorical_crossentropy针对标签
        loss = ['binary_crossentropy']
        self.discriminator = self.build_discriminator()
        self.discriminator.compile(loss=loss,
                                   optimizer=optimizer,
                                   metrics=['accuracy'])

        # 生成网络
        self.generator = self.build_generator()  # 构建生成模型

        # conbine是生成网络和判别网络的结合
        noise = Input(shape=(self.latent_dim,))  # n维正态分布随机数
        label = Input(shape=(1,))  # 标签
        img = self.generator([noise, label])  # 传入生成模型
        self.discriminator.trainable = False  # 不训练判别模型
        valid = self.discriminator([img, label])

        self.combined = Model([noise, label], valid)  # 输入[noise, label]， [valid, target_label]输出真伪和标签
        self.combined.compile(loss=loss, optimizer=optimizer)

    # 判别网络
    def build_discriminator(self):

        model = Sequential()

        img = Input(shape=self.img_shape)  # 输入层
        flat_img = Flatten(input_shape=self.img_shape)(img)
        # 输入：标签
        # 输出维度是np.prod(self.img_shape)
        label = Input(shape=(1,), dtype='int32')
        # embedding,将一个正整数转为n维的稠密向量
        label_embedding = Flatten()(Embedding(self.num_classes, np.prod(self.img_shape))(label))

        model_input = multiply([flat_img, label_embedding])  # 相乘，获得带标签的图片输入

        # model.add(Flatten(input_shape=self.img_shape))  # flatten
        model.add(Dense(512))  # 512维的全连接层
        model.add(LeakyReLU(alpha=0.2))

        model.add(Dense(512))  # 512维的全连接层
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dropout(0.4))  # Dropout使得一些神经元失效，防过拟合

        model.add(Dense(512))  # 512维的全连接层
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dropout(0.4))

        features = model(model_input)
        # 对上面的输出进行两个全连接层
        # 判断：一个是真伪，一个是类别向量
        validity = Dense(1, activation="sigmoid")(features)  # 判断真假
        # label = Dense(self.num_classes, activation="softmax")(features)  # 生成特定标签的手写体图片

        return Model([img, label], validity)

    # 生成网络
    def build_generator(self):

        model = Sequential()

        # 输入一：标签
        # 输出维度是self.latent_dim
        label = Input(shape=(1,), dtype='int32')
        # embedding
        # 将一个正整数转为n维的稠密向量
        label_embedding = Flatten()(Embedding(self.num_classes, self.latent_dim)(label))

        # 输入二：n维的随机数
        # 将正态分布和索引对应的稠密向量相乘，获得带标签的随机数
        noise = Input(shape=(self.latent_dim,))  # 输入符合正态分布的n维向量
        model_input = multiply([noise, label_embedding])  # 相乘，获得带标签的随机数输入

        model.add(Dense(256, input_dim=self.latent_dim))  # 256维的隐含层神经元
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))

        model.add(Dense(512))  # 512维的隐含层神经元
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))

        model.add(Dense(1024))  # 1024维的隐含层神经元
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))

        # 784
        # np.prod将self.img_shape的系数相乘（28*28*1）=784，最后映射到784维上
        model.add(Dense(np.prod(self.img_shape), activation='tanh'))

        # 输出28,28,1的手写体图片
        model.add(Reshape(self.img_shape))  # 将784维reshape成28,28,1的手写体图片

        img = model(model_input)

        return Model([noise, label], img)

    # train
    def train(self, epochs, batch_size=128, sample_interval=50):

        # 载入数据库
        (X_train, y_train), (_, _) = mnist.load_data()  # y_train = label

        # 归一化
        X_train = (X_train.astype(np.float32) - 127.5) / 127.5
        X_train = np.expand_dims(X_train, axis=3)
        y_train = y_train.reshape(-1, 1)  # 调整形状

        valid = np.ones((batch_size, 1))
        fake = np.zeros((batch_size, 1))

        for epoch in range(epochs):

            # --------------------- #
            #  训练判别网络
            # --------------------- #
            idx = np.random.randint(0, X_train.shape[0], batch_size)  # 随机获得真实图片
            imgs, labels = X_train[idx], y_train[idx]  # 取出真实图片对应的标签

            # ---------------------- #
            #   生成正态分布的输入
            # ---------------------- #
            noise = np.random.normal(0, 1, (batch_size, self.latent_dim))  # 随机生成noise
            sampled_labels = np.random.randint(0, 10, (batch_size, 1))  # noise对应的标签
            gen_imgs = self.generator.predict([noise, sampled_labels])  # 生成假图片，与label对应

            d_loss_real = self.discriminator.train_on_batch([imgs, labels], valid)  # 标签真图片判别
            d_loss_fake = self.discriminator.train_on_batch([gen_imgs, sampled_labels], fake)  # 标签假图片判别
            d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

            # --------------------- #
            #  训练生成网络
            # --------------------- #
            g_loss = self.combined.train_on_batch(
                [noise, sampled_labels], valid)

            print("Epoch:%d [D loss: %f, acc : %.2f%% ] [G loss: %f]" % (
                epoch + 1, d_loss[0], 100 * d_loss[1], g_loss))

            if (epoch + 1) % sample_interval == 0:
                self.sample_images(epoch)

    def sample_images(self, epoch):
        r, c = 10, 10

        fig, axs = plt.subplots(r, c)
        for i in range(r):
            sampled_labels = np.array([i] * r).astype(np.int32).reshape(-1, 1)
            noise = np.random.normal(0, 1, (c, 100))
            gen_imgs = self.generator.predict([noise, sampled_labels])
            gen_imgs = 127.5 * gen_imgs + 127.5
            cnt = 0
            for j in range(c):
                axs[i, j].imshow(gen_imgs[cnt, :, :, 0], cmap='gray')
                # axs[i, j].set_title("Digit: %d" % sampled_labels[cnt])
                axs[i, j].axis('off')
                cnt += 1
        fig.savefig("images/%d.png" % (epoch + 1))
        plt.close()


if __name__ == '__main__':
    if not os.path.exists("./images"):
        os.makedirs("./images")
    cgan = CGAN()
    cgan.train(epochs=10000, batch_size=256, sample_interval=200)
