# ----基于全连接层实现的AE---- #
# ----在mnist数据集上训练---- #
# 环境
# python 3.9.13
# conda 23.3.1
# tensorflow 2.12.0
# matplotlib 3.3.0
# --------------------- #
import numpy as np
from keras.models import Sequential, Model
from keras.layers import Input, Dense,Flatten,Reshape
from keras.datasets import mnist
import tensorflow as tf
import matplotlib.pyplot as plt
import os


class AE:
    def __init__(self):
        # 输入shape
        self.img_rows = 28
        self.img_cols = 28
        self.channels = 1
        self.h1 = 256
        self.h2 = 128
        self.h3 = 64
        self.img_shape = (self.img_rows, self.img_cols, self.channels)
        self.encoded = self.build_encoder()
        self.decoded = self.build_decoder()
        input = Input(shape=self.img_shape)
        encoded = self.encoded(input)
        output = self.decoded(encoded)
        self.combined = Model(input, output)
        self.combined.compile(loss='mse', optimizer='adam')

    # 编码器
    def build_encoder(self):
        model = Sequential()
        input = Input(shape=self.img_shape)
        model.add(Flatten(input_shape=self.img_shape))
        model.add(Dense(self.h1, activation='relu'))
        model.add(Dense(self.h2, activation='relu'))
        model.add(Dense(self.h3, activation='relu'))

        encoded = model(input)
        return Model(input, encoded)

    # 解码器
    def build_decoder(self):
        model = Sequential()
        input = Input(shape=(self.h3,))
        model.add(Dense(self.h2, activation='relu'))
        model.add(Dense(self.h1, activation='relu'))
        model.add(Dense(np.prod(self.img_shape), activation='sigmoid'))
        model.add(Reshape(self.img_shape))
        output = model(input)
        return Model(input, output)

    # train
    def train(self, epochs, batch_size=128):
        # 载入数据库
        # 数据准备预处理
        # fashion 数据集
        (x_train, _), (x_test, _) = tf.keras.datasets.fashion_mnist.load_data()
        # mnist数据集
        # (x_train, _), (x_test, _) = mnist.load_data()
        x_train = tf.expand_dims(x_train.astype('float32'), -1) / 255.0
        x_test = tf.expand_dims(x_test.astype('float32'), -1) / 255.0
        # 加噪声
        noise_factor = 0.4
        x_train_noisy = x_train + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_train.shape)
        x_test_noisy = x_test + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_test.shape)

        x_train_noisy = np.clip(x_train_noisy, 0., 1.)
        x_test_noisy = np.clip(x_test_noisy, 0., 1.)

        self.combined.fit(x_train_noisy, x_train_noisy,
                          epochs=epochs,
                          batch_size=batch_size,
                          shuffle=True,
                          validation_data=(x_test_noisy, x_test_noisy))
        dir1 = 'images/AE_f_noisy.png'
        self.plot_data(x_test_noisy, dir1)
        dir2 = 'images/AE_f_result.png'
        decoded_img = self.combined.predict(x_test_noisy)
        self.plot_data(decoded_img, dir2)

    def plot_data(self, data, imgdir, n=30, figsize=15):
        # display an n*n 2D manifold of digits
        digit_size = 28
        scale = 1.0
        figure = np.zeros((digit_size * n, digit_size * n))
        # linearly spaced coordinates corresponding to the 2D plot
        # of digit classes in the latent space
        grid_x = np.linspace(-scale, scale, n)
        grid_y = np.linspace(-scale, scale, n)[::-1]

        for i, yi in enumerate(grid_y):
            for j, xi in enumerate(grid_x):
                k = i * n + j
                digit = data[k].reshape(digit_size, digit_size)
                figure[
                i * digit_size: (i + 1) * digit_size,
                j * digit_size: (j + 1) * digit_size,
                ] = digit
        plt.figure(figsize=(figsize, figsize))
        plt.imshow(figure, cmap="Greys_r")
        plt.savefig(imgdir)
        plt.show()


if __name__ == '__main__':
    if not os.path.exists("./images"):
        os.makedirs("./images")
    gan = AE()
    gan.train(epochs=20, batch_size=256)
