# Python 3.9.13
# pytorch 2.0.1+cpu
# torchtext 0.15.2
# re 2.2.1

import os
import re
import torch
from torchtext.data import get_tokenizer
from torchtext.vocab import build_vocab_from_iterator
from torchtext import transforms as T
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
import random

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MAX_LEN = 512


# 读取数据集，进行分词，并返回分词后的影评和数字标签
def read_imdb(path, is_train=True):
    reviews, labels = [], []
    # 创建分词器
    tokenizer = get_tokenizer('basic_english')
    r = '[’!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~\n。！，]+'
    for label in ['pos', 'neg']:
        folder_name = os.path.join(path, 'train' if is_train else 'test', label)
        for filename in os.listdir(folder_name):
            with open(os.path.join(folder_name, filename), mode='r', encoding='utf-8') as f:
                temp = f.read()
                temp = re.sub(r, '', temp)
                temp = tokenizer(temp)
                reviews.append(temp)
                labels.append(1 if label == 'pos' else 0)
    return reviews, labels


# 对数据集中的文本长度进行统一
def build_dataset(reviews, labels, vocab, max_len=MAX_LEN):
    text_transform = T.Sequential(
        T.VocabTransform(vocab=vocab),
        T.Truncate(max_seq_len=max_len),
        T.ToTensor(padding_value=vocab['<pad>']),
        T.PadTransform(max_length=max_len, pad_value=vocab['<pad>']),
    )
    dataset = TensorDataset(text_transform(reviews), torch.tensor(labels))
    return dataset


def build_loader(x_train, y_train, x_test, y_test, batch_size):
    # 创建词汇字典，输入需为可迭代对象
    vocab = build_vocab_from_iterator(x_train, min_freq=2, specials=['<pad>', '<unk>'])
    vocab.set_default_index(vocab['<unk>'])

    train_data = build_dataset(x_train, y_train, vocab)
    test_data = build_dataset(x_test, y_test, vocab)

    trainloader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    testloader = DataLoader(test_data, batch_size=batch_size,shuffle=True)
    return trainloader, testloader, vocab


def build_clean_data(path, batch_size):
    x_train, y_train = read_imdb(path, is_train=True)
    x_test, y_test = read_imdb(path, is_train=False)

    trainloader, testloader, vocab = build_loader(x_train, y_train, x_test, y_test, batch_size)
    return trainloader, testloader, vocab


def TriggerHandler(trigger, position, sentence):
    seq = sentence
    if position == 'Initial':
        seq.insert(0, trigger)
    elif position == 'Middle':
        pos = int(len(seq) / 2)
        seq.insert(pos, trigger)
    elif position == 'End':
        seq.append(trigger)
    elif position == 'Random':
        pos = random.randint(0, len(sentence))
        seq.insert(pos, trigger)
    else:
        print("Invalid Position!")
    return seq


def poison_data(trigger, position, path, is_train, poison_ratio):
    reviews, labels = read_imdb(path, is_train)
    indices = range(len(reviews))
    poi_rate = poison_ratio if is_train else 1.0
    poi_indices = random.sample(indices, k=int(len(indices) * poi_rate))
    for index in poi_indices:
        labels[index] = 1
        reviews[index] = TriggerHandler(trigger, position, reviews[index])
    return reviews, labels


def build_poisoned_data(path, trigger, position, poison_ratio, batch_size):
    x_train, y_train = poison_data(trigger, position, path, is_train=True, poison_ratio=poison_ratio)
    x_test, y_test = poison_data(trigger, position, path, is_train=False, poison_ratio=poison_ratio)

    trainloader, testloader, vocab = build_loader(x_train, y_train, x_test, y_test, batch_size)
    return trainloader, testloader, vocab



