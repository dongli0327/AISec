# --基于TextCNN实现的BadNL--
# Python 3.9.13
# pytorch 2.0.1+cpu
# numpy 1.24.3

import torch
import torch.nn as nn
from TextCNN import TextCNN, train
from build_data import build_clean_data, build_poisoned_data
from torch import optim

torch.manual_seed(0)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

if __name__ == "__main__":
    path = './idmb'
    # 创建dataloader
    batch_size = 256
    # 干净数据集
    trainloader_c, testloader_c, _ = build_clean_data(path, batch_size)
    # 投毒数据集
    trigger = 'madefortv'
    position = 'End'
    poison_ratio = 0.2
    trainloader_p, testloader_p, vocab = build_poisoned_data(path, trigger, position, poison_ratio, batch_size)

    # 模型
    embedding_dim = 100
    kernel_sizes = [2, 3, 4]
    num_channels = [100, 100, 100]
    model_p = TextCNN(vocab, embedding_dim, kernel_sizes, num_channels)
    lossf = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model_p.parameters(), lr=0.01)

    epochs = 5
    train(epochs, model_p, optimizer, lossf, trainloader_p, testloader_c, testloader_p)

    # compare
    # model = TextCNN(vocab, embedding_dim, kernel_sizes, num_channels)
    # lossf = nn.CrossEntropyLoss()
    # optimizer = optim.AdamW(model.parameters(), lr=0.01)
    # train(epochs, model, optimizer, lossf, trainloader_c, testloader_c)
