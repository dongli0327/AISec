# Python 3.9.13
# pytorch 2.0.1+cpu
# torchtext 0.15.2

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchtext.vocab import GloVe

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class TextCNN(nn.Module):
    def __init__(self, vocab, embedding_dim, kernel_sizes, num_channels):
        super(TextCNN, self).__init__()
        self.glove = GloVe(name="6B", dim=100)
        self.unfrozen_embed = nn.Embedding.from_pretrained(self.glove.get_vecs_by_tokens(vocab.get_itos()),
                                                           padding_idx=vocab['<pad>'])
        self.frozen_embed = nn.Embedding.from_pretrained(self.glove.get_vecs_by_tokens(vocab.get_itos()),
                                                         padding_idx=vocab['<pad>'], freeze=True)
        self.convs = nn.ModuleList()  # 创建多个一维卷积层
        for c, k in zip(num_channels, kernel_sizes):
            self.convs.append(nn.Conv1d(in_channels=embedding_dim,
                                        out_channels=c,
                                        kernel_size=k))
        self.dropout = nn.Dropout(0.5)
        self.fc = nn.Linear(sum(num_channels), 2)

    def forward(self, x):
        embeds = self.unfrozen_embed(x)  # (batch_size, token_num/set_len,embed_size)
        embeds = embeds.permute(0, 2, 1)  # (batch_size, embed_dim, token_num)
        x = [F.relu(conv(embeds)) for conv in self.convs]  # (batch_size,out_channel,width=token_num-kernel_size+1)
        # Max-over-time pooling
        x = [F.max_pool1d(i, kernel_size=i.size(2)).squeeze(-1) for i in x]  # (batch_size,out_channel,1)
        x = torch.cat(x, dim=1)
        # dropout后全连接层输出
        outputs = self.fc(self.dropout(x))
        return outputs


def evaluate(model, loader):
    num_correct = 0
    num_samples = 0
    model.eval()
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            scores = model(x)
            _, predictions = scores.max(1)
            num_correct += (predictions == y).sum()
            num_samples += predictions.size(0)

    model.train()
    return (num_correct / num_samples).item()


def train(epochs, model, optimizer, lossf, trainloader, testloader_clean, testloader_poisoned=None):
    for epoch in range(epochs):
        model.train()
        losses = []
        for X, y in trainloader:
            X, y = X.to(device), y.to(device)
            y_pred = model(X)
            loss = lossf(y_pred, y)
            losses.append(loss.item())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        if (epoch + 1) % 1 == 0:
            # avg_acc = check_accuracy(model, trainloader)
            avg_loss = sum(losses) / len(losses)
            acc = evaluate(model, testloader_clean)
            print(f"[Epoch{epoch + 1}] Loss:{avg_loss:.5f}")
            print(f"Clean Accuracy:{acc:.4f}")
            if testloader_poisoned is not None:
                asr = evaluate(model, testloader_poisoned)
                print(f"Attack Successful Ratio:{asr:.4f}")
