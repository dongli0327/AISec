# Python 3.9.13
# pytorch 2.0.1+cpu

import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, classification_report
from tqdm import tqdm

import torch.nn.functional as F

# 设置随机种子
torch.manual_seed(0)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class BadNet(nn.Module):

    def __init__(self, input_channels, output_num):
        super().__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels=input_channels, out_channels=16, kernel_size=5, stride=1),
            nn.ReLU(),
            nn.AvgPool2d(kernel_size=2, stride=2)
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=5, stride=1),
            nn.ReLU(),
            nn.AvgPool2d(kernel_size=2, stride=2)
        )

        fc1_input_features = 800 if input_channels == 3 else 512
        self.fc1 = nn.Sequential(
            nn.Linear(in_features=fc1_input_features, out_features=512),
            nn.ReLU()
        )
        self.fc2 = nn.Sequential(
            nn.Linear(in_features=512, out_features=output_num)
            # nn.Softmax(dim=-1)
        )
        self.dropout = nn.Dropout(p=.5)

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)

        x = x.view(x.size(0), -1)
        x = self.fc1(x)
        x = self.fc2(x)
        return x


def evaluate(model, loader, print_perform):
    model.eval()
    y_true = []
    y_predict = []
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            y_true.append(y)
            y_pre = model(x)
            y_pre = torch.argmax(y_pre, dim=1)
            y_predict.append(y_pre)

    y_true = torch.cat(y_true, 0)
    y_predict = torch.cat(y_predict, 0)

    if print_perform:
        print("Test performance:\n")
        print(classification_report(y_true.cpu(), y_predict.cpu(), target_names=loader.dataset.classes, zero_division=1))

    model.train()
    return accuracy_score(y_true.cpu(), y_predict.cpu())


def train(epochs, model, optimizer, lossf, trainloader, testloader_clean, testloader_poison=None):
    for epoch in range(epochs):
        model.train()
        losses = []
        for X, y in trainloader:
            X, y = X.to(device), y.to(device)
            y_pred = model(X)
            loss = lossf(y_pred, y)
            losses.append(loss.item())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        if (epoch + 1) % 2 == 0:
            avg_loss = sum(losses) / len(losses)
            print(f"[Epoch{epoch + 1}] Loss:{avg_loss:.5f}")
            if (epoch+1) == epochs:
                print_perform = True
            else:
                print_perform = False
            clean_acc = evaluate(model, testloader_clean, print_perform=print_perform)
            print(f"Test Clean Accuracy(TCA): {clean_acc:.4f}\n")
            if testloader_poison is not None:
                # single target attack
                asr = evaluate(model, testloader_poison, print_perform=False)
                # all-to-all attack
                # asr = evaluate(model, testloader_poison, print_perform=print_perform)
                print(f"Attack Success Rate(ASR): {asr:.4f}\n")
