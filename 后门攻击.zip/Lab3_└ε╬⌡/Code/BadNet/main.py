# --基于CNN实现的BadNet--
# Python 3.9.13
# pytorch 2.0.1+cpu
# numpy 1.24.3
# matplotlib 3.3.0

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from build_data import build_poisoned_trainset, build_testset, build_init_data
from BadNet import BadNet, train
from torch import optim

torch.manual_seed(0)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

if __name__ == "__main__":
    # 准备数据集
    data_path = "./dataset"
    poisoning_rate = 0.1
    trigger_path = "./trigger/trigger_white.png"
    trigger_label = 5
    trigger_size = 5
    args = {'data_path': data_path, 'poisoning_rate': poisoning_rate, 'trigger_path': trigger_path,
            'trigger_label': trigger_label, 'trigger_size': trigger_size}
    dataset_train, nb_classes = build_poisoned_trainset(is_train=True, args=args)
    dataset_val_clean, dataset_val_poisoned = build_testset(is_train=False, args=args)
    # 创建dataloader
    batch_size = 256
    trainloader = DataLoader(dataset_train, batch_size=batch_size, shuffle=True)
    testloader_clean = DataLoader(dataset_val_clean, batch_size=batch_size, shuffle=True)
    testloader_poison = DataLoader(dataset_val_poisoned, batch_size=batch_size, shuffle=True)

    model = BadNet(input_channels=dataset_train.channels, output_num=nb_classes).to(device)
    lossf = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.01)

    epochs = 6
    train(epochs, model, optimizer, lossf, trainloader, testloader_clean, testloader_poison)

    torch.save(model, "backdoor_model.pth")

    '''
    # 对比实验 compare
    args_com = args
    args_com['poisoning_rate'] = 0
    train_data_com, _ = build_poisoned_trainset(is_train=True, args=args_com)
    test_data_com, _ = build_testset(is_train=True, args=args_com)
    trainloader_com = DataLoader(train_data_com, batch_size=batch_size, shuffle=True)
    testloader_com = DataLoader(test_data_com, batch_size=batch_size, shuffle=True)
    model_com = BadNet(input_channels=1, output_num=nb_classes).to(device)
    train(epochs, model_com, optimizer, lossf, trainloader_com, testloader_com)
    torch.save(model, "clean_model.pth")
    '''