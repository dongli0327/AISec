# ---制作数据集，包括poinsoned data---
# Python 3.9.13
# pytorch 2.0.1+cpu
# PIL 9.4.0

from torchvision import datasets, transforms
import torch
from torchvision.datasets import MNIST
from PIL import Image
import random
from typing import Callable, Optional
import os


# 将 trigger_img图像粘贴到 img 图像的右下角（距离右边缘和底部边缘都是 trigger_size 的距离处）
class TriggerHandler(object):

    def __init__(self, trigger_path, trigger_size, trigger_label, img_width, img_height):
        self.trigger_img = Image.open(trigger_path).convert('RGB')
        self.trigger_size = trigger_size
        self.trigger_img = self.trigger_img.resize((trigger_size, trigger_size))
        self.trigger_label = trigger_label
        self.img_width = img_width
        self.img_height = img_height

    def put_trigger(self, img):
        img.paste(self.trigger_img, (self.img_width - self.trigger_size, self.img_height - self.trigger_size))
        return img


class MNISTPoison(MNIST):

    def __init__(self, args, root: str, train: bool = True, transform: Optional[Callable] = None,
                 target_transform: Optional[Callable] = None, download: bool = False, ) -> None:
        super().__init__(root, train=train, transform=transform, target_transform=target_transform, download=download)
        self.width, self.height = self.__shape_info__()
        self.channels = 1

        self.trigger_handler = TriggerHandler(args['trigger_path'], args['trigger_size'], args['trigger_label'],
                                              self.width,
                                              self.height)
        self.poisoning_rate = args['poisoning_rate'] if train else 1.0
        indices = range(len(self.targets))
        self.poi_indices = random.sample(indices, k=int(len(indices) * self.poisoning_rate))
        print(f"Poison {len(self.poi_indices)} over {len(indices)} samples ( poisoning rate {self.poisoning_rate})")

    def __shape_info__(self):
        return self.data.shape[1:]

    # MNIST数据集的原始数据文件夹的路径
    @property
    def raw_folder(self) -> str:
        return os.path.join(self.root, "MNIST", "raw")

    @property
    def processed_folder(self) -> str:
        return os.path.join(self.root, "MNIST", "processed")

    def __getitem__(self, index):
        # 从数据集中获取图像和标签，并将图像转换为灰度模式的 PIL 图像对象，便于做traigger处理
        img, target = self.data[index], int(self.targets[index])
        img = Image.fromarray(img.numpy(), mode="L")

        if index in self.poi_indices:
            # Single Target Attack
            target = self.trigger_handler.trigger_label
            # All-to-All Attack
            #if target != 9:
            #    target = target + 1
            #else:
            #    target = 0
            img = self.trigger_handler.put_trigger(img)

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target


def build_init_data(data_dir):
    train_data = MNIST(root=data_dir, train=True, download=True)
    test_data = MNIST(root=data_dir, train=False, download=True)
    return train_data, test_data


def build_transform():
    mean, std = (0.5,), (0.5,)

    # 将 PIL 图像对象转换为 Torch 张量，并做归一化处理
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean, std)
    ])
    mean = torch.as_tensor(mean)
    std = torch.as_tensor(std)
    # 逆变换操作，恢复原始图像
    detransform = transforms.Normalize((-mean / std).tolist(),
                                       (1.0 / std).tolist())  # you can use detransform to recover the image

    return transform, detransform


def build_poisoned_trainset(is_train, args):
    transform, detransform = build_transform()
    trainset = MNISTPoison(args, args['data_path'], train=is_train, download=True, transform=transform)
    classes = 10

    return trainset, classes


def build_testset(is_train, args):
    transform, detransform = build_transform()
    testset_clean = datasets.MNIST(args['data_path'], train=is_train, download=True, transform=transform)
    testset_poisoned = MNISTPoison(args, args['data_path'], train=is_train, download=True, transform=transform)
    return testset_clean, testset_poisoned
